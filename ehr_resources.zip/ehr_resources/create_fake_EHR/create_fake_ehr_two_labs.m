clear all;
close all;


N=100; % number of patients
m=100; %maximum number of time points per patient
tmax=1000; %maximum length of record

%do the first patient by hand
nm=randi(m);
times1=randperm(tmax, nm);
times1=times1.';
times1=sort(times1);

lab1=rand(nm,1);

times2=randperm(tmax, nm);
times2=times2.';
times2=sort(times2);

lab2=rand(nm,1);

ehrV1(1:nm,1)=1;
ehrV1(1:nm,2)=times1;
ehrV1(1:nm,3)=lab1;

ehrV2(1:nm,1)=1;
ehrV2(1:nm,2)=times2;
ehrV2(1:nm,3)=lab2;


for(i=2:N)
    clear nm times1 times2 lab1 lab2;
    nm=randi(m); %set number of measurements for this patient
    %p = randperm(n,k) returns a row vector containing k unique 
    % integers selected randomly from 1 to n inclusive.
    times1=randperm(tmax, nm);
    times1=times1.';
    times1=sort(times1);
    
    lab1=rand(nm,1);
    
    times2=randperm(tmax, nm);
    times2=times2.';
    times2=sort(times2);

    lab2=rand(nm,1);
    
    [el, foo]=size(ehrV1);
    ehrV1(el+1:el+nm,1)=i;
    ehrV1(el+1:el+nm,2)=times1;
    ehrV1(el+1:el+nm,3)=lab1;
    
    [el, foo]=size(ehrV2);
    ehrV2(el+1:el+nm,1)=i;
    ehrV2(el+1:el+nm,2)=times2;
    ehrV2(el+1:el+nm,3)=lab2;
    
end;

dlmwrite('lab1.data', ehrV1, 'delimiter', '\t');
dlmwrite('lab2.data', ehrV2, 'delimiter', '\t');


