function [patient]=patient_isolation_trick(A, desired_id)

j = 1;
[m,n]=size(A);

while j<m+1
a = A(j,1);


v = (A(:,1)==a);
nv = sum(v);
B = zeros(m,nv);

B(j:(j+nv-1),:) = eye(nv);

C = A'*B;

A1 = C';

if(A1(1,1)==desired_id)
    patient=A1;
end;

j=j+nv;
clear v nv B C A1


end



