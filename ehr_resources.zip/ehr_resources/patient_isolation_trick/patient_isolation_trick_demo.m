%load some data --- A is the EHR.
load A.mat

%designate the patient identifier that we want to isolate
desired_id=3;

%run the isolation
p=patient_isolation_trick(A, desired_id);
%thus returning the record, p, for patient with the desired id
