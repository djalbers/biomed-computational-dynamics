clear all;

%load the data
A=load('fake_data.data') 

aux = abs((A(:,2)-round(A(:,2))));

b=(aux>0.10000001);

B=[b b];


A1 = A.*B;


A2 = sortrows(A1);

n = sum(A2(:,1)==0);


[m,m1] = size(A);

C(1:n,1:m-n) = zeros([n,m-n]);

C(n+1:m,1:m-n)=eye(m-n);

A3 = A2'*C;

A_new = A3'
