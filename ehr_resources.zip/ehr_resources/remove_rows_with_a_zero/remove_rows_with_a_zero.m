%assuming a matrix A

%~any(A(:,1),2) creates a vector with a 0 whenever there is a zero in
% A(:,1) 

%remove if there is a zero in column 1 
A( ~any(A(:,1),2), : ) = [];

%remove if there is a zero in column 2 
A( ~any(A(:,2),2), : ) = [];
