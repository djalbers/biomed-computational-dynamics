function [patient_to_output] = select_N_random_patients(home_directory, working_directory, input_data_file_name, number_of_random_patients_wanted, minimum_number_of_measurements)

output_directory=working_directory;

addpath([working_directory, '/matlab_src']);

M=number_of_random_patients_wanted;

%declarations for load data
data_file_name=[working_directory, '/', input_data_file_name];
load_file_at_once=1;
file_style=1;

load_data;

clear N;
%now, let us define N as the number of patients
N=max(size(number_of_readings));

i=1;
while (i<=M)
    m=randi(N,1);   
    if(number_of_readings(m)>minimum_number_of_measurements)
        if(m==1)
            starting_point=1;
            ending_point=number_of_readings(1);
        else
            starting_point=sum(number_of_readings(1:(m-1)))+1;
            ending_point=starting_point+number_of_readings(m)-1;
        end;
        clear foo_patient;
        
        foo_patient=data(starting_point:ending_point, 1:3);
        
        if(i==1)
            patient_to_output=foo_patient;
        else
            patient_to_output=cat(1,patient_to_output, foo_patient);
        end;
        i=i+1;
    end;
    
end;


dlmwrite([working_directory, '/N_random_patients.data'], patient_to_output, 'delimiter', '\t', 'precision', 6);

