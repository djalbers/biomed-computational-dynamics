%clear all;
%close all;

function select_N_random_patients(home_directory, working_directory, input_data_file_name, number_of_random_patients_wanted, minimum_number_of_measurements)

output_directory=working_directory;

addpath([working_directory, '/matlab_src']);

%clear M;
M=number_of_random_patients_wanted;
%minimum_number_of_measurements=2;

%declarations for load data
data_file_name=[working_directory, '/', input_data_file_name];
load_file_at_once=1;
file_style=1;

load_data;

clear N;
%now, let us define N as the number of patients
N=max(size(number_of_readings));

readings_to_choose_from=find(number_of_readings>minimum_number_of_measurements);

%make sure you have enough to choose from
if(max(size(readings_to_choose_from))>=M)

    %select random numbers
    clear a b;
    a=min(readings_to_choose_from);
    b=max(readings_to_choose_from);
    random_patient_index=intersect(1,0); %note this will just create an empty array
    for(i=1:M)
        m=randi([a,b],1);
        while(ismember(m,readings_to_choose_from)==1 && ismember(m,random_patient_index)==0)
            m=randi([a,b],1);
        end;
        random_patient_index(i)=m;
    end;

    for(i=1:M)
        %fprintf('%g \n', i);
        m=random_patient_index(i);
        starting_point=sum(number_of_readings(1:(m-1)))+1;
        ending_point=starting_point+number_of_readings(m)-1;
        
        clear foo_patient;
        
        foo_patient=data(starting_point:ending_point, 1:3);
        
        if(i==1)
        patient_to_output=foo_patient;
        else
            patient_to_output=cat(1,patient_to_output, foo_patient);
        end;
    end;

    dlmwrite([working_directory, '/N_random_patients.data'], patient_to_output, 'delimiter', '\t', 'precision', 6);
else
    patient_to_output=-10000;
    dlmwrite([working_directory, '/N_random_patients.data'], patient_to_output, 'delimiter', '\t', 'precision', 6);
end;

