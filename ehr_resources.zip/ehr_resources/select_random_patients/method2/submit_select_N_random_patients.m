home_directory=pwd;
working_directory=pwd;
input_data_file_name='data.foo';
number_of_random_patients_wanted=10;
minimum_number_of_measurements=2;

select_N_random_patients(home_directory, working_directory, input_data_file_name, number_of_random_patients_wanted, minimum_number_of_measurements);

